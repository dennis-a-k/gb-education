-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Июн 28 2020 г., 18:09
-- Версия сервера: 5.7.26
-- Версия PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gb_lesson_php-1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `img_gallery`
--

CREATE TABLE `img_gallery` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `path` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `img_gallery`
--

INSERT INTO `img_gallery` (`id`, `name`, `path`) VALUES
(1, 'Wallpaper-1', 'windows-10-1.jpg'),
(2, 'Wallpaper-2', 'windows-10-2.jpg'),
(3, 'Wallpaper-3', 'windows-10-3.jpg'),
(4, 'Wallpaper-5', 'windows-10-5.jpg'),
(5, 'Wallpaper-6', 'windows-10-6.jpg'),
(6, 'Wallpaper-7', 'windows-10-7.jpg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `img_gallery`
--
ALTER TABLE `img_gallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `img_gallery`
--
ALTER TABLE `img_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
